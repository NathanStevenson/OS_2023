#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <unistd.h>
#include <cstring>
#include <vector>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
using namespace std;

void parse_and_run_command(const std::string &command) {
    /* TODO: Implement this. */
    /* Note that this is not the correct way to test for the exit command.
       For example the command "   exit  " should also exit your shell.
    */
    // vector of strings will contain each file, operation, or argument in its own index
    vector<string> strings = {};
    string curWord = "";
    int status;
    for(int i=0; i < (int)command.length(); i++){
        if (command[i] == ' ' || command[i] == '\t' || command[i] == '\v') {
            if(curWord != ""){ strings.push_back(curWord); }
            curWord = "";
        } else if (i == (int)command.length()-1) {
            curWord += command[i];
            strings.push_back(curWord);
        } else { curWord += command[i]; }
    }
    // change the vector of strings to format that can be passed into exec
    const char **argv = new const char* [strings.size()+1];
    
    // parsing and counter to track for malformed commands
    int count_input = 0;
    int count_output = 0;
    int count_length = 0;
    string input_filename = "";
    string output_filename = "";

    // Iterate through and check if malformed, and also prepare output/input redirections.
    for(int i=0; i < (int)strings.size(); i++){
        if (strings[i] == "<" || strings[i] == ">"){
            // check that it is not an operator or empty and that we are not out of bounds
            // if a proper string
            if (i+1 < (int)strings.size() && strings[i+1] != "<" && strings[i+1] != ">" && strings[i+1] != ""){ //check if piping later
                // keep track of filename
                // specify if input or output char
                // if input redirection
                if (strings[i] == "<"){
                    count_input++;
                    if (count_input > 1){
                        std::cerr << "invalid command.\n";
                    } else {
                        input_filename = strings[i+1];
                        i++;
                    }
                } else if (strings[i] == ">") {
                    count_output++;
                    if (count_output > 1) {
                        std::cerr << "invalid command.\n";
                    } else {
                        output_filename = strings[i+1];
                        i++;
                    }
                }
            // if we have a redirection token followed by something other than a word
            } else {
                std::cerr << "invalid command. (Input token followed by non-word)\n";
            }
        } else {
            // really stupid we were setting argv[i] equal to string[1]. This would only work if command came first
            // we need to be setting it to be count_length instead otherwise we were getting like: "< Makefile /bin/cat > output.txt"
            // since "/bin/cat" is at strings[3] we were setting argv[3] to it and then setting argv[1] to null making argv[0] also null
            // when we were printing all of argv[i] we could not tell we should have printed the iterator next to it to see what index the output was in bc the rest printed null
            argv[count_length] = strings[i].c_str();
            count_length++;
        }
    }
    argv[count_length] = NULL;
   
    // /usr/bin/wc < Makefile > wc.out
    // argv: "/usr/bin/wc", "<", "Makefile", ">", "wc.out"
    // argv: "/bin/cat Makefile" ">"
    if(count_length == 0){
        std::cerr << "invalid command\n";
    }
    // if special keyword to exit the custom terminal
    if (command == "exit") {
        exit(0);
    }

    int pid = fork();
    // child copy of parent where we will execute the command
    if(pid == 0){
        // this is where file redirection occurs
        if (input_filename != ""){
            close(0);
            int fd_in = open(input_filename.c_str(), O_RDWR);
            if (fd_in < 0){
                std::cerr << "invalid command";
            }
        }
        if (output_filename != ""){
            // this is saying that we are opening a file for read/write. Creating it if it doesnt exist and truncating it to 0 if it does
            // the last two arguments are also giving the permissions of the file
            // documentation found on this man page: https://pubs.opengroup.org/onlinepubs/9699919799.2013edition/functions/open.html
            close(1);
            int fd_out = open(output_filename.c_str(), O_RDWR | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
            if (fd_out < 0){
                std::cerr << "invalid command";
            }      
        }
        // pass to exec
        int retVal = execv(argv[0], (char**)argv);
        if (retVal < 0){
            std::cerr << "Exit Status 255 (Command not found). Error preventing running the executable.\n";
        }
    }
    // parent waiting on child to finish execution
    else if (pid > 0){
        wait(&status);
        if (WIFEXITED(status)){
            cout << argv[0] << " exit status: " << WEXITSTATUS(status) << endl;
        }
    }
    // 
    else{
        std::cerr << "Fork Error.\n";
    }
    delete[](argv);
}

int main(void) {
    std::string command;
    std::cout << "> ";
    while (std::getline(std::cin, command)) {
        parse_and_run_command(command);
        std::cout << "> ";
    }
    return 0;
}
